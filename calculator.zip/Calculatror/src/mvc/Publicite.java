package mvc;

import javax.swing.*;
import java.awt.*;

public class Publicite {
    JFrame frame;
    JLabel image=new JLabel(new ImageIcon(getClass().getResource("/images/giphy.gif")));
    JProgressBar progressBar=new JProgressBar();
    
    
    Publicite()
    {
        creerPub();
        ajouterImage();
        ajoutProgressBar();
        marcherProgressBar();
        System.out.println("pub bon");
    }
    public void creerPub(){
        frame=new JFrame();
        frame.setTitle("Publicite");
        frame.getContentPane().setLayout(null);
        frame.setSize(200,400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
    public void ajouterImage(){
        image.setSize(200,300);
        frame.add(image);
    }
    
   
    public void ajoutProgressBar(){
        progressBar.setBounds(50,100,100,30);
        progressBar.setLocation(43, 315);
        progressBar.setBorderPainted(true);
        progressBar.setStringPainted(true);
        progressBar.setBackground(Color.WHITE);
        progressBar.setForeground(Color.RED);
        progressBar.setValue(0);
        frame.add(progressBar);
    }
    public void marcherProgressBar(){
        int i=0;

        while( i<=100)
        {
            try{
                Thread.sleep(100);
                progressBar.setValue(i);
                i++;
                if(i==100)
                frame.dispose();
                	
            }catch(Exception e){
                e.printStackTrace();
            }           
        }
    }
     
}