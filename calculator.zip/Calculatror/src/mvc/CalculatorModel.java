package mvc;

import java.util.Random;

import javax.swing.JOptionPane;

public class CalculatorModel {
	
	public static int A = (int)(Math.random()*11);
	public static int B = (int)(Math.random()*(11-A)); 
	public static int resultat;
	
	
	
	public static void Calculer() {
		Random r = new Random();
		char operateur ='x';
		int A = (int)(Math.random()*11);
		int B = (int)(Math.random()*(11-A));
		do {
			
			switch (r.nextInt(2)){
			case 0: operateur = '+';
            resultat = A+B;
            break;
			case 1: operateur = '-';
            resultat = A-B;
            break;
			
			}
			if (resultat > 0) { 
				CalculatorView.zoneCalcul.setText("CALCUL :"+ " "+ A+" "+operateur+" "+B);// = "+resultat);
		    	  break;	
		}
			}while(A<B);
		 
		System.out.println("calcul bon");
	}
	
	
	
	


}
