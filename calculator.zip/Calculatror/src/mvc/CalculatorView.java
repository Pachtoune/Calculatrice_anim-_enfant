package mvc;
 
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;





public class CalculatorView extends JFrame implements ActionListener{
	static JFrame frame = new JFrame();
	int counter =3;
	private static JButton moins = new JButton("-");
	private static JButton plus = new JButton("+");
	private static JButton valider = new JButton("valider");
	public static JLabel zoneCalcul = new JLabel();
	public static JLabel zoneReponse = new JLabel();
	public static JLabel zoneRecommencer = new JLabel ();
	
	ImageIcon images[];
	int i;
	
	
	
	
	
	
		
	public CalculatorView() {

		
		this.setTitle("Frame");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(200, 450);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setVisible(true);
		JPanel calcPanel = new JPanel();
		calcPanel.setBackground(Color.orange);
		zoneCalcul.setFont(new Font("Serif", Font.PLAIN, 20));
		zoneReponse.setPreferredSize(new Dimension(300, 265));
		images = new ImageIcon[11];
		
		images[0] = new ImageIcon(getClass().getResource("/images/0.gif"));
		images[1] = new ImageIcon(getClass().getResource("/images/1.gif"));
		images[2] = new ImageIcon(getClass().getResource("/images/2.gif"));
		images[3] = new ImageIcon(getClass().getResource("/images/3.gif"));
		images[4] = new ImageIcon(getClass().getResource("/images/4.gif"));
		images[5] = new ImageIcon(getClass().getResource("/images/5.gif"));
		images[6] = new ImageIcon(getClass().getResource("/images/6.gif"));
		images[7] = new ImageIcon(getClass().getResource("/images/7.gif"));
		images[8] = new ImageIcon(getClass().getResource("/images/8.gif"));
		images[9] = new ImageIcon(getClass().getResource("/images/9.gif"));
		images[10] = new ImageIcon(getClass().getResource("/images/10.gif"));
		zoneReponse.setIcon(images[0]);
		zoneReponse.setHorizontalAlignment(JLabel.CENTER);
		
		moins.setPreferredSize(new Dimension(80, 25));
		plus.setPreferredSize(new Dimension(80, 25));
		valider.setPreferredSize(new Dimension(150, 25));
		
		
		calcPanel.add(zoneCalcul);
		calcPanel.add(zoneRecommencer);
		calcPanel.add(zoneReponse);
		calcPanel.add(moins);
		calcPanel.add(plus);
		calcPanel.add(valider);		
		this.add(calcPanel);
		moins.addActionListener(this);
		plus.addActionListener(this);
		valider.addActionListener(this);
		zoneRecommencer.setText(counter + " " + "essaie restante");
	}
	
	
		
	@Override
	public void actionPerformed(ActionEvent e) { // methode d'ecoute
		
	

	if(e.getSource()==moins) // qd on appuie sur le -
	   {
	       if(i==0)
	       {
	           JOptionPane.showMessageDialog(null,"AVERTISSEMENT !\n\n Le r�sultat ne peut pas �tre n�gatif !");
	       }
	       else
	           {
	           i=i-1;
	           zoneReponse.setIcon(images[i]);
	           zoneReponse.setText(Integer.toString(i)); 

	           }
	       System.out.println("moins bon");
	   }

	   if(e.getSource()==plus)
	   {
	       if(i==images.length-1)
	       {
	           JOptionPane.showMessageDialog(null,"AVERTISSEMENT !\n\n Le r�sultat ne peut pas d�passer 10 !");
	       }
	       else
	           {
	           i=i+1;
	           zoneReponse.setIcon(images[i]);
	           zoneReponse.setText(Integer.toString(i));
	           }
	       System.out.println("plus bon");
	       }
	   
	   /*if ((e.getSource()== valider) && CalculatorModel.resultat==Integer.parseInt(CalculatorView.zoneReponse.getText())) {
	JOptionPane.showMessageDialog(null, "BRAVO !\n\n la r�ponse du calcul �tait bien " + "  "  + CalculatorModel.resultat);
		try {
			Thread.sleep(100);
		}
		catch (InterruptedException a) {
		
		}
		   
		System.exit((50));
		
	}
	   
	   if ((e.getSource()== valider) && CalculatorModel.resultat!=Integer.parseInt(CalculatorView.zoneReponse.getText())) {
		   
		   
		   /*JOptionPane.showMessageDialog(null, "FAUX ! \n\n La bonne r�ponse du calcul est : "+"  "  + CalculatorModel.resultat);
		try {
			Thread.sleep(100);
		}
		catch (InterruptedException a) {
	
		}
		   
		   
		System.exit(50);

	}*/
	   if (e.getSource() == valider){
		   if(CalculatorModel.resultat==Integer.parseInt(CalculatorView.zoneReponse.getText())) {
			   JOptionPane.showMessageDialog(null, "BRAVO !\n\n la r�ponse du calcul �tait bien " + "  "  + CalculatorModel.resultat);
			   
			   Object[] options = {"OUI","NON"};
			   int n = JOptionPane.showOptionDialog(null,"Veux-tu recommencer ?","Recommencer",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
			   
			        if(n==0){
			        	CalculatorModel.Calculer();
			        }
			        else{
			        	
			        	 //PubliciteFin pubF = new PubliciteFin();
			        	 System.exit(50);
			        }
			        System.out.println("valider bon");
		   }
		     
		   else{
			   if(counter> 0) 
			   counter--;
			   JOptionPane.showMessageDialog(null, "Et non, le resultat du calcul n'est pas "+ Integer.parseInt(CalculatorView.zoneReponse.getText()) +"\nIl te reste "+counter+ "essai(s).");
			   zoneRecommencer.setText(counter +  " " +" essai(s) restant(s)");
			   
				if(counter==0) {
					Object[] options = {"OUI","NON"};
					int n = JOptionPane.showOptionDialog(null,"Veux-tu recommencer ?","Recommencer",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
					if(n==0){
						counter = 3;
						zoneRecommencer.setText(counter + " " +" essai(s) restant(s)");
			        	CalculatorModel.Calculer();
			        }
			        else{
			        	
			        	//PubliciteFin pubF = new PubliciteFin();
			        	 System.exit(50);
			        	 
			        }
					
				}   
				   			   
		   }
		   }		   
	   }
	   
	}
		
			 
				
			
			  	
			    
		
		


