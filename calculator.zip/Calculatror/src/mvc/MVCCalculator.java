package mvc;

public class MVCCalculator {
	
	private CalculatorView theView;
	private CalculatorModel theModel;
	
	
	public MVCCalculator(CalculatorView theView, CalculatorModel theModel) {
		this.theView = theView;
		this.theModel = theModel;	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Publicite publicite = new Publicite();
		CalculatorView theView = new CalculatorView();
		CalculatorModel theModel = new CalculatorModel();
		theModel.Calculer();
		
		
		
		
		
	}
}
